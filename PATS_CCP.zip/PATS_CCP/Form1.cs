﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Peak.Can.Basic;
using Peak.Can.Ccp;

using TCCPHandle = System.UInt32;
using TPCANHandle = System.UInt16;

namespace CCPDemo
{
    public partial class Form1 : Form
    {
        private TCCPHandle m_PccpHandle;
        private TPCANHandle m_Channel;
        private TPCANBaudrate m_Baudrate;
        private TCCPSlaveData m_SlaveData;
        private TCCPExchangeData m_ExchangeData;

        public Form1()
        {
            InitializeComponent();

            m_PccpHandle = 0;

            // PCAN Hardware to use
            m_Channel = PCANBasic.PCAN_USBBUS1;
            m_Baudrate = TPCANBaudrate.PCAN_BAUD_500K;

        }

        private string GetErrorText(TCCPResult errorCode)
        {
            StringBuilder strText = new StringBuilder(256);

            if (CCPApi.GetErrorText(errorCode, strText) == TCCPResult.CCP_ERROR_ACKNOWLEDGE_OK)
                return strText.ToString();
            return String.Empty;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnConnect.Enabled = false;
            btnTest.Enabled = false;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            CCPApi.UninitializeChannel(m_Channel);
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            TCCPResult result;
            bool bConnected;

            result = CCPApi.Connect(m_Channel, ref m_SlaveData, out m_PccpHandle, 1000);
            bConnected = (result == TCCPResult.CCP_ERROR_ACKNOWLEDGE_OK);

            btnConnect.Enabled = !bConnected;
            btnDisconnect.Enabled = bConnected;
            btnGetVersion.Enabled = bConnected;
            btnExchangeId.Enabled = bConnected;

            if (!bConnected)
                MessageBox.Show("Error: " + GetErrorText(result), "Error");
        }

        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            TCCPResult result;

            result = CCPApi.Disconnect(m_PccpHandle, false, 0);
            m_PccpHandle = 0;

            btnConnect.Enabled = true;
            btnDisconnect.Enabled = false;
            btnGetVersion.Enabled = false;
            btnExchangeId.Enabled = false;

            if (result != TCCPResult.CCP_ERROR_ACKNOWLEDGE_OK)
                MessageBox.Show("Error: " + GetErrorText(result), "Error");

            laVersion.Text = "0.0";
            laSlaveInfo.Text = "_________";
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            TCCPResult result;

            result = CCPApi.Test(m_Channel, ref m_SlaveData, 0);

            if(result == TCCPResult.CCP_ERROR_ACKNOWLEDGE_OK)
                MessageBox.Show("ECU is available for connect");
            else if(result == TCCPResult.CCP_ERROR_INTERNAL_TIMEOUT)
                MessageBox.Show("ECU NOT available");
            else
                MessageBox.Show("Error: " + GetErrorText(result),"Error");
        }

        private void btnGetVersion_Click(object sender, EventArgs e)
        {
            TCCPResult result;
            byte main, release;

            main = release = 0;
            result = CCPApi.GetCcpVersion(m_PccpHandle, ref main, ref release, 0);

            if (result != TCCPResult.CCP_ERROR_ACKNOWLEDGE_OK)
                MessageBox.Show("Error: " + GetErrorText(result), "Error");
            else
                laVersion.Text = string.Format("{0}.{1}", main, release);
        }

        private void btnExchangeId_Click(object sender, EventArgs e)
        {
            TCCPResult result;
            byte[] masterData;

            masterData = new byte[4] { 0x00, 0x00, 0x00, 0x00 };
            result = CCPApi.ExchangeId(m_PccpHandle, ref m_ExchangeData, masterData, masterData.Length, 0);

            result = CCPApi.Upload(m_PccpHandle, 5, masterData, 500);
            result = CCPApi.Upload(m_PccpHandle, 5, masterData, 500);
            result = CCPApi.Upload(m_PccpHandle, 2, masterData, 500);

            if (result != TCCPResult.CCP_ERROR_ACKNOWLEDGE_OK)
                MessageBox.Show("Error: " + GetErrorText(result), "Error");
            else
            {
                laSlaveInfo.Text = string.Format("ID Length {0}. Data Type {1}. Res. Mask {2}. Protec. Mask {3}.", new object[] { m_ExchangeData.IdLength, m_ExchangeData.DataType, m_ExchangeData.AvailabilityMask, m_ExchangeData.ProtectionMask });
            }
        }

        private void A2lFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog fdlg = new OpenFileDialog();
            fdlg.Title = "Select a Excel file";
            //fdlg.InitialDirectory = @"D:\";
            fdlg.Filter = "Excel Files (*.a2l*)|*.a2l*";
            if (fdlg.ShowDialog() == DialogResult.OK)
            {
                textBox3.Text = fdlg.FileName;
            }
        }

        private void Initialize_Click(object sender, EventArgs e)
        {
            TCCPResult result;

            string str2 = textBox2.Text;
            uint DTO = Convert.ToUInt32(str2, 16);

            string str1 = textBox1.Text;
            uint CRO = Convert.ToUInt32(str1, 16);

            m_SlaveData = new TCCPSlaveData();
            m_SlaveData.EcuAddress = 0x0;
            m_SlaveData.IdCRO = CRO;    // PC send (RX)
            m_SlaveData.IdDTO = DTO;    // ECU send (TX)
            m_SlaveData.IntelFormat = true;


            result = CCPApi.InitializeChannel(m_Channel, m_Baudrate);
            if (result != TCCPResult.CCP_ERROR_ACKNOWLEDGE_OK)
            {
                MessageBox.Show("Error: " + GetErrorText(result), "Error");
                btnConnect.Enabled = false;
                btnTest.Enabled = false;
            }
            else
            {
                btnConnect.Enabled = true;
                btnTest.Enabled = true;
            }
        }

        private void CreateFailure_Click(object sender, EventArgs e)
        {
            byte MTA0Ext = 0;  // Memory address extension
     //       uint MTA0Addr = 0x4000C084;  // CCP_FAILURE Address in A2l file
            uint MTA0Addr = 0x84C00040;
            TCCPResult callResult;

            string strData = "01070040";  // CCP Value for failure
            byte[] strTemp = StringToByteArray(strData);

            byte[] requstData;
            requstData = new byte[4] { 0x40, 0x01, 0x02, 0x78 };
            CCPApi.ShortUpload(m_PccpHandle, 4, MTA0Ext, MTA0Addr, requstData, 1000);
            CCPApi.ShortUpload(m_PccpHandle, 4, MTA0Ext, MTA0Addr, requstData, 1000);
            CCPApi.ShortUpload(m_PccpHandle, 4, MTA0Ext, MTA0Addr, requstData, 1000);

            // Set memory address.
            CCPApi.SetMemoryTransferAddress(m_PccpHandle, 0, MTA0Ext, MTA0Addr, 1000);

            // Download data to fix address.
            callResult = CCPApi.Download(m_PccpHandle, strTemp, 4, out MTA0Ext, out MTA0Addr, 1000);

            if (callResult != TCCPResult.CCP_ERROR_ACKNOWLEDGE_OK)
                MessageBox.Show("Error: " + GetErrorText(callResult), "Error");
            else
            MessageBox.Show("Failure cretaed");

        }

        private void RemoveFailure_Click(object sender, EventArgs e)
        {
            byte MTA0Ext = 0;  // Memory address extension
            //       uint MTA0Addr = 0x4000C084;  // CCP_FAILURE Address in A2l file
            uint MTA0Addr = 0x84C00040;
            TCCPResult callResult;

            string strData = "01070000";  // CCP Value for failure
            byte[] strTemp = StringToByteArray(strData);

            byte[] requstData;
            requstData = new byte[4] { 0x40, 0x01, 0x02, 0x78 };
            CCPApi.ShortUpload(m_PccpHandle, 4, MTA0Ext, MTA0Addr, requstData, 1000);
            CCPApi.ShortUpload(m_PccpHandle, 4, MTA0Ext, MTA0Addr, requstData, 1000);
            CCPApi.ShortUpload(m_PccpHandle, 4, MTA0Ext, MTA0Addr, requstData, 1000);

            // Set memory address.
            CCPApi.SetMemoryTransferAddress(m_PccpHandle, 0, MTA0Ext, MTA0Addr, 1000);

            // Download data to fix address.
            callResult = CCPApi.Download(m_PccpHandle, strTemp, 4, out MTA0Ext, out MTA0Addr, 1000);

            if (callResult != TCCPResult.CCP_ERROR_ACKNOWLEDGE_OK)
                MessageBox.Show("Error: " + GetErrorText(callResult), "Error");
            else
                MessageBox.Show("Failure Removed");
        }

        public static byte[] StringToByteArray(String hex)
        {
            int NumberChars = hex.Length;
            byte[] bytes = new byte[NumberChars / 2];
            for (int i = 0; i < NumberChars; i += 2)
                bytes[i / 2] = Convert.ToByte(hex.Substring(i, 2), 16);
            return bytes;
        } 

    }
}
